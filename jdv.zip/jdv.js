var tamanhoc = 13;
var corcv = "turquoise";
var corcm = "white";
var corborda = "LightGreen";
function desenha() {
	 var canvas = document.getElementById('tela');
  	 if (canvas.getContext) {
	    var ctx = canvas.getContext('2d');
	    ctx.lineTo(300,30);
	    ctx.lineTo(0,30);
	    ctx.lineTo(300,60);
	    ctx.lineTo(0,60);
	    ctx.lineTo(300,90);
	    ctx.lineTo(0,90);
	    ctx.lineTo(300,120);
	    ctx.lineTo(0,120);
	
	    ctx.stroke();
	  
	  }
}